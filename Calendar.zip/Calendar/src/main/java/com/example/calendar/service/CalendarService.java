package com.example.calendar.service;

import com.example.calendar.model.Calendar;
import com.example.calendar.repository.CalendarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

@Service
public class CalendarService {

    private final CalendarRepository calendarRepository;

    @Autowired
    public CalendarService(CalendarRepository calendarRepository) {
        this.calendarRepository = calendarRepository;
    }

    public Calendar findbyID(Long id){
        return calendarRepository.findById(id).orElse(null);
    }

    public List<Calendar> findAll(){
        return calendarRepository.findAll();
    }

    public Calendar saveCalendar(Calendar calendar){
        return calendarRepository.save(calendar);
    }

    public void deelteByID(Long id){
        calendarRepository.deleteById(id);
    }
}
