package com.example.calendar.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name ="calendar")
public class Calendar {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "data")
    private String data;
    @Column(name = "event")
    private String event;
}
