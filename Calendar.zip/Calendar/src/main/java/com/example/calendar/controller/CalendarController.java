package com.example.calendar.controller;

import com.example.calendar.model.Calendar;
import com.example.calendar.service.CalendarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class CalendarController {
    private CalendarService calendarService;
    @Autowired
    public CalendarController(CalendarService calendarService) {
        this.calendarService = calendarService;
    }


    @GetMapping("/calendars")
    public String findAll(Model model){
        List<Calendar> calendars = calendarService.findAll();
        model.addAttribute("calendars", calendars);
        return "calendar-list";
    }

    @GetMapping("/calendar-create")
    public String createEventForm(Calendar calendar){
        return "calendar-create";
    }

    @PostMapping("/calendar-create")
    public String createEvent(Calendar calendar){
        calendarService.saveCalendar(calendar);
        return "/redirect:/calendars";
    }

    @GetMapping("calendar-delete/{id}")
    public String deleteCalendar(@PathVariable("id") Long id){
        calendarService.deelteByID(id);
        return "redirect:/calendars";
    }
}
